import express from "express";
import cors from "cors";
import dotenv from "dotenv";
import OpenAI from "openai";

dotenv.config();
const app = express();
app.use(cors());
app.use(express.json({ limit: "1mb" }));

if (!process.env.OPENAI_API_KEY) {
  console.error("Missing OPENAI_API_KEY. Add it to server/.env");
  process.exit(1);
}
const client = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

app.get("/health", (_req, res) => res.json({ ok: true, app: "Jarvis" }));

app.post("/chat", async (req, res) => {
  try {
    const messages = Array.isArray(req.body.messages) ? req.body.messages : [];
    const safeMessages = messages.slice(-12).map(m => ({
      role: m.role === "assistant" ? "assistant" : "user",
      content: String(m.content ?? "").slice(0, 8000)
    }));
    const result = await client.chat.completions.create({
      model: process.env.OPENAI_MODEL || "gpt-4o-mini",
      messages: [
        {
          role: "system",
          content: "You are Jarvis, a helpful, capable personal AI assistant. Understand Hindi, Marathi, and English. Be proactive and practical. Explain when an action requires phone permissions or cannot be performed. Never claim you performed an action unless a connected tool actually did it. Do not assist with harmful or illegal activity."
        },
        ...safeMessages
      ],
      temperature: 0.7
    });
    res.json({ reply: result.choices[0]?.message?.content || "I don't have a reply yet." });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "AI request failed", detail: err.message });
  }
});

const port = Number(process.env.PORT || 3000);
app.listen(port, "0.0.0.0", () => console.log(`Jarvis server listening on ${port}`));
