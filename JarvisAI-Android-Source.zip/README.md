# Jarvis AI — Android starter project

This is a starter Android app with:
- Chat screen connected to an AI backend
- Text-to-speech replies
- Speech-to-text input using Android's speech recognition
- A “Hey Jarvis” trigger mode: tap the mic, say “Hey Jarvis” followed by a command
- Hindi/English-friendly assistant instructions on the backend

## Important voice limitation
The current wake phrase is **not** an always-on background hotword detector. Android's standard speech-recognition UI is started when you tap the microphone. The app can detect “Hey Jarvis” in that spoken result while the app is open. True hands-free, background wake-word detection needs a dedicated on-device wake-word engine, a microphone foreground service, notification, battery/privacy handling, and device testing.

## Requirements
- Android Studio (current stable)
- JDK 17
- Node.js 18+
- An OpenAI API key

## Start the AI backend
1. Open a terminal in `server/`.
2. Run `npm install`.
3. Copy `.env.example` to `.env`.
4. Put your API key in `.env` (never put it in the Android app).
5. Run `npm start`.
6. Confirm `http://localhost:3000/health` returns `{ "ok": true, "app": "Jarvis" }`.

## Run the Android app
1. Open the project root in Android Studio and let Gradle sync.
2. For the Android emulator, the default backend URL `http://10.0.2.2:3000` points to your computer.
3. For a physical phone, edit `API_BASE_URL` in `app/build.gradle.kts` to your computer's LAN IP, for example `http://192.168.1.10:3000`. Keep the phone and computer on the same Wi-Fi.
4. Run the app. Allow microphone permission when Android asks.
5. Type a message, or tap the mic to speak. Enable Voice Activation and say “Hey Jarvis” followed by your command after tapping the mic.

## What this version can and cannot do
- It can chat through the configured AI backend and speak replies aloud.
- It can recognize speech through the Android speech-recognition provider.
- It does not yet execute arbitrary phone actions, send messages, place calls, or change settings. Those require separate Android intents/APIs, explicit user permissions, and confirmation flows.
- Do not expose your API key in the app or publish `.env`.
- The sample backend uses a model name configurable through `OPENAI_MODEL`; choose a model available to your API account.
