package com.jarvis.ai

import android.content.Intent
import android.os.Bundle
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.Locale
import java.util.concurrent.TimeUnit

private val navy = Color(0xFF07111F)
private val panel = Color(0xFF122238)
private val cyan = Color(0xFF26C6DA)
private val http = OkHttpClient.Builder()
    .connectTimeout(20, TimeUnit.SECONDS)
    .readTimeout(60, TimeUnit.SECONDS)
    .build()

data class ChatMessage(val text: String, val fromUser: Boolean)

class MainActivity : ComponentActivity() {
    private var tts: TextToSpeech? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this) { status ->
            if (status == TextToSpeech.SUCCESS) {
                tts?.language = Locale.getDefault()
            }
        }
        setContent { JarvisScreen(onSpeak = { speak(it) }) }
    }

    private fun speak(text: String) {
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "jarvis_reply")
    }

    override fun onDestroy() {
        tts?.shutdown()
        super.onDestroy()
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun JarvisScreen(onSpeak: (String) -> Unit) {
    val messages = remember {
        mutableStateListOf(ChatMessage("Hello! I'm Jarvis. Tap the mic or enable voice trigger and say “Hey Jarvis”.", false))
    }
    var input by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf("") }
    var wakeMode by remember { mutableStateOf(false) }
    var status by remember { mutableStateOf("Ready") }
    val scope = rememberCoroutineScope()

    fun addUserMessage(text: String) {
        if (text.isBlank()) return
        messages.add(ChatMessage(text, true))
        input = ""
        error = ""
        busy = true
        status = "Jarvis is thinking…"
        scope.launch {
            val answer = withContext(Dispatchers.IO) { askJarvis(messages.toList()) }
            messages.add(ChatMessage(answer, false))
            busy = false
            status = if (wakeMode) "Voice trigger mode on — say Hey Jarvis" else "Ready"
            onSpeak(answer)
        }
    }

    val speechLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        val spoken = result.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
        if (!spoken.isNullOrBlank()) {
            val normalized = spoken.trim()
            if (wakeMode) {
                val lower = normalized.lowercase(Locale.getDefault())
                val wakeIndex = lower.indexOf("hey jarvis")
                if (wakeIndex >= 0) {
                    val command = normalized.substring(wakeIndex + "hey jarvis".length).trim()
                    if (command.isNotBlank()) addUserMessage(command)
                    else {
                        status = "I'm listening — say your command"
                        input = ""
                    }
                } else {
                    status = "Didn't hear “Hey Jarvis”. Try again."
                }
            } else {
                input = normalized
            }
        } else {
            status = if (wakeMode) "Voice trigger mode on — tap mic to listen again" else "Ready"
        }
    }

    fun startListening() {
        try {
            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, "en-IN")
                putExtra(RecognizerIntent.EXTRA_PROMPT, if (wakeMode) "Say Hey Jarvis, then your command" else "Speak to Jarvis")
            }
            speechLauncher.launch(intent)
        } catch (_: Exception) {
            error = "Speech recognition isn't available on this phone. You can type instead."
        }
    }

    MaterialTheme(colorScheme = darkColorScheme(
        primary = cyan, background = navy, surface = panel,
        onPrimary = navy, onBackground = Color.White, onSurface = Color.White
    )) {
        Scaffold(
            containerColor = navy,
            topBar = {
                TopAppBar(
                    title = {
                        Column {
                            Text("JARVIS", color = Color.White, fontSize = 22.sp)
                            Text("Your all-in-one AI assistant", color = cyan, fontSize = 12.sp)
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(containerColor = navy)
                )
            }
        ) { padding ->
            Column(Modifier.fillMaxSize().padding(padding).padding(14.dp)) {
                Row(
                    Modifier.fillMaxWidth().background(panel, RoundedCornerShape(16.dp)).padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(Modifier.weight(1f)) {
                        Text("VOICE ACTIVATION", color = cyan, fontSize = 11.sp)
                        Text(status, color = Color.White, fontSize = 13.sp)
                    }
                    Switch(checked = wakeMode, onCheckedChange = {
                        wakeMode = it
                        status = if (it) "Voice trigger enabled — tap mic and say Hey Jarvis" else "Ready"
                    })
                }
                Spacer(Modifier.height(10.dp))
                LazyColumn(
                    modifier = Modifier.weight(1f).fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                    contentPadding = PaddingValues(vertical = 8.dp)
                ) {
                    items(messages) { msg ->
                        Row(
                            Modifier.fillMaxWidth(),
                            horizontalArrangement = if (msg.fromUser) Arrangement.End else Arrangement.Start
                        ) {
                            Column(
                                Modifier.widthIn(max = 310.dp)
                                    .background(if (msg.fromUser) Color(0xFF075B70) else panel,
                                        RoundedCornerShape(16.dp))
                                    .padding(13.dp)
                            ) {
                                Text(if (msg.fromUser) "YOU" else "JARVIS", color = cyan, fontSize = 10.sp)
                                Spacer(Modifier.height(4.dp))
                                Text(msg.text, color = Color.White, fontSize = 15.sp)
                                if (!msg.fromUser) {
                                    TextButton(onClick = { onSpeak(msg.text) }) {
                                        Icon(Icons.Default.VolumeUp, null, tint = cyan)
                                        Text("  Read aloud", color = cyan)
                                    }
                                }
                            }
                        }
                    }
                    if (busy) item { Text("Jarvis is thinking…", color = cyan) }
                }
                if (error.isNotBlank()) Text(error, color = Color(0xFFFF8A80), fontSize = 12.sp)
                Row(
                    Modifier.fillMaxWidth().background(panel, RoundedCornerShape(24.dp)).padding(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    BasicTextField(
                        value = input,
                        onValueChange = { input = it },
                        modifier = Modifier.weight(1f).padding(horizontal = 10.dp, vertical = 12.dp),
                        textStyle = androidx.compose.ui.text.TextStyle(color = Color.White, fontSize = 15.sp),
                        decorationBox = { inner ->
                            if (input.isEmpty()) Text("Message Jarvis…", color = Color.LightGray)
                            inner()
                        }
                    )
                    IconButton(onClick = { startListening() }) {
                        Icon(Icons.Default.Mic, "Voice input", tint = cyan)
                    }
                    IconButton(
                        enabled = input.isNotBlank() && !busy,
                        onClick = { addUserMessage(input) }
                    ) {
                        Icon(Icons.Default.Send, "Send", tint = cyan)
                    }
                }
                Spacer(Modifier.height(8.dp))
                Text(
                    "Voice trigger is foreground-only in this starter build. Keep Jarvis open and tap the mic to start speech recognition.",
                    color = Color.LightGray, fontSize = 10.sp
                )
            }
        }
    }
}

private fun askJarvis(history: List<ChatMessage>): String {
    return try {
        val messages = JSONArray()
        history.takeLast(12).forEach {
            messages.put(JSONObject()
                .put("role", if (it.fromUser) "user" else "assistant")
                .put("content", it.text))
        }
        val body = JSONObject().put("messages", messages).toString()
            .toRequestBody("application/json; charset=utf-8".toMediaType())
        val request = Request.Builder()
            .url("${BuildConfig.API_BASE_URL}/chat")
            .post(body)
            .build()
        http.newCall(request).execute().use { response ->
            val responseBody = response.body?.string().orEmpty()
            if (!response.isSuccessful) {
                "I couldn't connect to my AI server (${response.code}). Check the server setup and network."
            } else {
                JSONObject(responseBody).optString("reply", "I didn't receive a reply.")
            }
        }
    } catch (e: Exception) {
        "I can't reach the AI server. Start the Jarvis server and check API_BASE_URL. Details: ${e.localizedMessage ?: "network error"}"
    }
}
